/**
 * 
 * Program for applying watermarks on images
 * 
 * !!! Supports these extensions:
 * .jpg, .png, ...
 * 
 */
package whatermarkprogram;

import java.util.Scanner;

import java.io.File; //This is so I can use directory path names.
import java.io.IOException; //This is to handle errors.
import java.awt.image.BufferedImage; //This is for image handeling, to create Bufferedimage object. Object is used to store image in RAM.
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO; // This is for preforming read and write on image files.

/**
 *
 * @author Gregor Stojanovic, gregor.stojanovic.18@singimail.rs (tikkygames@gmail.com)
 * @version 0.1
 * 
 */
public class WhaterMarkProgram {

    public static void main(String[] args) {
        
        String Path;
        
        Scanner scan = new Scanner(System.in);
        
        ImageHandler image = new ImageHandler();
        
        BufferedImage temp;
        
        image.LoadImage("img/test.jpg");
        
        temp = image.getImage();
        
        temp = image.WhatermarkAdd("It's me Mario");
        
        
        image.WriteImage("img/out/testOut.png", temp);
        

        
        
    }
    
}
