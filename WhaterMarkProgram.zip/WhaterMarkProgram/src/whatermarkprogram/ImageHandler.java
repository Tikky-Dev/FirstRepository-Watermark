package whatermarkprogram;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.List;
import java.io.File; //This is so I can use directory path names.
import java.io.IOException; //This is to handle errors.
import java.awt.image.BufferedImage; //This is for image handeling, to create Bufferedimage object. Object is used to store image in RAM.
import java.awt.image.RenderedImage;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO; // This is for preforming read and write on image files.


/**
 *
 * @author Gregor Stojanovic, gregor.stojanovic.18@singimail.rs (tikkygames@gmail.com)
 * @version 0.1
 * 
 */
public class ImageHandler {
       

    public ImageHandler() {
    }

    public BufferedImage getImage() {
        return image;
    }
    
    
    
    
    BufferedImage image = null;
    
//    Read image 
    public void LoadImage (String path){
        
        try{
            File inputImage = new File(path); 
            
            
            
            this.image = ImageIO.read(inputImage);
                        
            
            
//            image = new BufferedImage(width, lenght, BufferedImage.TYPE_INT_ARGB);  //image in RAM.
                        
            
            
            System.out.println("Reading Compleat");
            
        }
        catch(IOException e){
            System.out.println("Error: " + e);
        }
        
    }
    
    
//    Writh Image
    public void WriteImage(String path, RenderedImage image){
        
        try {
            
            File outImage = new File(path);
                   
            ImageIO.write(image, "png", outImage);
            
            System.out.println("Writing Compleat");
            
        } 
        catch (IOException ex) {
            System.out.println("Error: " + ex);
        }    
        
    }
    
    public BufferedImage WhatermarkAdd(String watermark){
        
        BufferedImage temp = new BufferedImage(this.image.getWidth(), this.image.getHeight(), BufferedImage.TYPE_INT_RGB);
        
        Graphics graphic = temp.getGraphics();
        
        graphic.drawImage(image, 0, 0, null);
        
        graphic.setFont(new Font("Times New Roman", Font.PLAIN, 50));
        graphic.setColor(Color.getHSBColor(45, 125, 5));
        
        
        graphic.drawString(watermark, this.image.getWidth()/5, this.image.getHeight()/3);
        
        graphic.dispose();
        
        
        
        return temp;
    }
    

    
}
